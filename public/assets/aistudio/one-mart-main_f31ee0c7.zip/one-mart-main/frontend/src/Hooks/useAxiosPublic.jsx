import axios from "axios";

const axiosPublic=axios.create({
    // baseURL: 'https://one-mart-backend-one.vercel.app'
    baseURL: 'http://localhost:5000'
})
const useAxiosPublic = () => {
    return axiosPublic
};

export default useAxiosPublic;